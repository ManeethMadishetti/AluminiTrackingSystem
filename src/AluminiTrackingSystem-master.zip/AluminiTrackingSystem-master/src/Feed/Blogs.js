import React from 'react'
import {withRouter} from 'react-router-dom';

const Blogs = () => {
    return (
        <div>
            <h1>Hello We are in Blogs session</h1>
        </div>
    )
}

export default withRouter(Blogs);
